package com.openclassrooms.realestatemanager.controller;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

import com.openclassrooms.realestatemanager.R;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class AuthenticationActivity extends AppCompatActivity {

    @BindView(R.id.activity_authentication_edittext_user_agent_name)
    EditText mEditTextUserAgentName;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authentication);
        ButterKnife.bind(this);
    }

    @OnClick(R.id.activity_authentication_button)
    public void onClickButtonContinue(){
        if(mEditTextUserAgentName.getText().toString().length() != 0){
            startActivity(new Intent(this, MainActivity.class));
        }
    }
}